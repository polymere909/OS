#!/bin/bash

current_time=$(date +%s)

echo "Current time: $current_time and current time doubled: $((current_time * 2)) "
