#!/bin/bash

for i in {1..20}
do
 echo $i
done
